package com.project.educonnect.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.educonnect.dto.ApplicantDTO;
import com.project.educonnect.model.Application;
import com.project.educonnect.model.OpportunityPost;
import com.project.educonnect.model.ProfessionalProfile;
import com.project.educonnect.model.StudentProfile;
import com.project.educonnect.repository.ApplicationRepository;
import com.project.educonnect.repository.PostRepository;
import com.project.educonnect.repository.ProfessionalProfileRepository;
import com.project.educonnect.repository.StudentProfileRepository;
import com.project.educonnect.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ApplicationService {

    @Autowired
    private ApplicationRepository repository;
    @Autowired
    private PostRepository postRepository;

    @Autowired
    private StudentProfileRepository studentProfileRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private AppNotificationService appNotificationService;

    @Autowired
    private ProfessionalProfileRepository professionalProfileRepository;

    public boolean apply(String studentId, String postId) {

        boolean alreadyApplied = repository.findByStudentIdAndPostId(studentId, postId)
                .isPresent();

        if (alreadyApplied) {
            return false;
        }
        

        Application app = new Application();

        app.setStudentId(studentId);
        app.setPostId(postId);
        app.setStatus("APPLIED");
        app.setAppliedAt(LocalDate.now());

        repository.save(app);
        // Notify the organization
        appNotificationService.createApplicationNotification(studentId, postId, "APPLIED");
        Optional<OpportunityPost> optionalPost = postRepository.findById(postId);

        if (optionalPost.isPresent()) {

            OpportunityPost post = optionalPost.get();

            post.setTotalApplicants(
                    post.getTotalApplicants() + 1);

            postRepository.save(post);
        }

        return true;
    }

    public List<String> getAppliedPostIds(String studentId) {

        return repository.findByStudentId(studentId)
                .stream()
                .map(Application::getPostId)
                .collect(Collectors.toList());
    }

    public List<Application> getStudentApplications(String studentId) {

        return repository.findByStudentId(studentId);

    }

    public List<ApplicantDTO> getApplicantsForOrg(String orgUserId) {

        // Step 1: Get all posts of this org
        List<OpportunityPost> orgPosts = postRepository.findByOrganizationId(orgUserId);

        if (orgPosts.isEmpty()) {
            return new ArrayList<>();
        }

        // Step 2: Extract post IDs
        List<String> postIds = orgPosts.stream()
                .map(OpportunityPost::getId)
                .collect(Collectors.toList());

        // Step 3: Get applications
        List<Application> applications = repository.findByPostIdIn(postIds);

        if (applications.isEmpty()) {
            return new ArrayList<>();
        }

        // Step 4: Map posts for quick lookup
        Map<String, OpportunityPost> postMap = orgPosts.stream()
                .collect(Collectors.toMap(OpportunityPost::getId, p -> p));

        List<ApplicantDTO> result = new ArrayList<>();

        for (Application app : applications) {

            ApplicantDTO dto = new ApplicantDTO();

            // =========================
            // APPLICATION INFO
            // =========================
            dto.setApplicationId(app.getId());
            dto.setStatus(app.getStatus());
            dto.setAppliedAt(
                    app.getAppliedAt() != null
                            ? app.getAppliedAt().toString()
                            : "N/A");

            // =========================
            // POST INFO
            // =========================
            OpportunityPost post = postMap.get(app.getPostId());

            if (post != null) {
                dto.setPostId(post.getId());
                dto.setPostTitle(post.getTitle());
                dto.setPostType(post.getType());
            }

            // =========================
            // USER INFO (COMMON)
            // =========================
            String userId = app.getStudentId(); // (actually applicantId)

            userRepository.findByUserId(userId).ifPresent(user -> {
                dto.setStudentName(user.getFullName());
                dto.setStudentEmail(user.getEmail());
            });

            // =========================
            // PROFILE INFO (FIXED LOGIC)
            // =========================
            String skills = null;
            String education = null;
            String location = null;
            String bio = null;
            String university = null;
            String company = null;
            // 1. Try Student Profile
            StudentProfile student = studentProfileRepository.findByUserId(userId);

            if (student != null) {
                skills = student.getStudentSkills();
                education = student.getStudentEducation();
                university = student.getStudentUniversity();
                location = student.getLocation();
                bio = student.getBio();
            }

            // 2. If NOT student → try Professional Profile
            ProfessionalProfile professional = professionalProfileRepository.findByUserId(userId);

            if (professional != null) {
                skills = professional.getSkills();
                education = professional.getEducation();
                location = professional.getLocation();
                bio = professional.getBio();
                company = professional.getCompany();
                
            }

            // =========================
            // DTO ASSIGNMENT (FINAL)
            // =========================
            dto.setSkills(skills != null ? skills : "N/A");
            dto.setEducation(education != null ? education : "N/A");
            dto.setUniversity(university);
            dto.setLocation(location != null ? location : "N/A");
            dto.setBio(bio != null ? bio : "N/A");
            
            result.add(dto);
        }

        return result;
    }

    public List<Application> getApplicationsByPostId(
            String postId) {

        return applicationRepository.findByPostId(postId);
    }

    public Application save(Application application) {

        return repository.save(application);
    }

    public Application updateStatus(
            String applicationId,
            String status) {

        Application app = applicationRepository
                .findById(applicationId)
                .orElse(null);

        if (app == null) {
            return null;
        }

        app.setStatus(status);

        return applicationRepository.save(app);
    }

    public void cancelApplication(String applicationId) {

        Application application = applicationRepository
                .findById(applicationId)
                .orElse(null);

        if (application == null) {
            return;
        }

        // GET POST ID

        String postId = application.getPostId();

        // FIND POST

        OpportunityPost post = postRepository
                .findById(postId)
                .orElse(null);

        // DECREASE TOTAL APPLICANTS

        if (post != null) {

            int currentCount = post.getTotalApplicants();

            // PREVENT NEGATIVE VALUE

            if (currentCount > 0) {

                post.setTotalApplicants(
                        currentCount - 1);
            }

            postRepository.save(post);
        }

        // DELETE APPLICATION
        // Notify the organization
        appNotificationService.createApplicationNotification(
                application.getStudentId(), application.getPostId(), "CANCELLED");
        applicationRepository.deleteById(
                applicationId);
    }
}