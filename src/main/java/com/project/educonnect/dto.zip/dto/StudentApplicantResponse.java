package com.project.educonnect.dto;

import lombok.Data;

@Data
public class StudentApplicantResponse {

    private String fullName;

    private String email;

    private String location;

    private String university;

    private String education;

    private String skills;

    private String bio;

    private String applicationId;
    private String status;
}